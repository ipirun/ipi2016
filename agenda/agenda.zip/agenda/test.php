


<?php

$toto= array(1, 20 ,"jiji","fifi", rand());
print_r($toto);

file_put_contents("data.json", json_encode($toto));
?>
