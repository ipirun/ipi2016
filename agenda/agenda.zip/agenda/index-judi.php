

<?php
/**
 * The main template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package bootstrapwp
 */

 ?><!doctype html>

<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>Projet Agenda</title>
  <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="./css/bootstrap.css" >
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="./js/bootstrap.js"></script>

<div class="container">
<div class="row">
<
<div id="banner" class="jumbotron">
<h1 style="color:black;">Agenda</h1>
<div ><p style="color:black;">Ajout de rendez-vous en fonction des disponibilité des commerciaux
</p></div>
<p><a class="btn btn-primary btn-lg" href="#" role="button" >En savoir plus</a></p>
</div>
</div>
</div>

<div class="container">
<div class="row">

</head>


<body>


  <!-- Mon bouton déroularant
  **/ -->


<div class="container">
<div class="row">
  <div class="column">
    <div class="col-md-6">

<div class="dropdown">
<button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
  Commerciaux
  <span class="caret"></span>
</button>
<ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
  <li><a href="#">Mr GRONDIN</a></li>
  <li><a href="#">Mr Judicael</a></li>
  <li><a href="#">Mr PAYET</a></li>
</ul>
</div>

    </div>
  </div>


  <!-- voir disponibilité du commerciaux
  **/ -->
  <div class="column">
    <div class="col-md-6">
<button type="button" class="btn btn-default navbar-btn">Voir disponibilité</button>
    </div>
    </div>


</div>
</div>

<!-- Agenda
**/ -->
<div class="container">
<div class="row">
  <div class="column">
    <div class="col-md-6">

<table class="table">
  ...
</table>

</div>
</div>
</div>
</div>



  <!-- Formulaire clients
  **/ -->

<div class="container">
  <div class="row">
    <div class="column">
      <div class="col-md-6">
        <form role="form">
          <div class="form-group">
            <label for="exampleInputEmail1">Nom de la socété</label>
            <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Nom de la socièté">
          </div>
        </form>



          </div>
        </div>


<button type="button" class="btn btn-default navbar-btn">Valider reservation</button>

        <div class="column">
          <div class="col-md-6">




              </div>
            </div>
      </div>
    </div>







</body>
</html>
