<?php



$toto=file_get_contents("data.json");
print_r(json_decode($toto));


?>
